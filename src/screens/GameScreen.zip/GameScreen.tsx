import React, { useCallback, useEffect, useRef, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { COW_HEIGHT, COW_WIDTH, Cow } from '../components/atoms/Cow';
import { Enemy } from '../components/atoms/Enemy';
import { CurrentScore } from '../components/molecules/CurrentScore';
import { TouchControls } from '../components/molecules/TouchControls';
import { GameOverModal } from '../components/organisms/GameOverModal';
import { COLORS, SCREEN_HEIGHT, SCREEN_WIDTH } from '../constants/theme';
import SkiaObstacles from './SkiaObstacles';

const FALLBACK_SCREEN_WIDTH = 360;
const FALLBACK_SCREEN_HEIGHT = 640;

const PLAYER_START_X = 50;
const GROUND_HEIGHT = 100;
const MOVE_SPEED = 265;
const AIR_MOVE_SPEED = 305;
const GRAVITY = 1900;
const JUMP_SPEED = 720;
const MAX_FALL_SPEED = 950;
const APEX_VELOCITY_THRESHOLD = 140;
const APEX_GRAVITY_FACTOR = 0.55;
const CAMERA_OFFSET_X = SCREEN_WIDTH * 0.32;
const RENDER_INTERVAL = 1 / 30;
const INITIAL_NEXT_OBSTACLE_X = 1380;
const OBSTACLE_GAP_MIN = 238;
const OBSTACLE_GAP_MAX = 360;
const SPAWN_GAP = 150;
const GENERATION_AHEAD = 760;
const CRATE_MIN_WIDTH = 64;
const CRATE_MAX_WIDTH = 104;
const CRATE_MIN_HEIGHT = 38;
const CRATE_MAX_HEIGHT = 58;
const SPIKE_MIN_WIDTH = 50;
const SPIKE_MAX_WIDTH = 64;
const SPIKE_HEIGHT = 22;
const ENEMY_WIDTH = 64;
const ENEMY_HEIGHT = 64;
const ENEMY_SPEED = 62;
const ENEMY_PATROL_RANGE = 160;
const FLOATING_MIN_WIDTH = 40;
const FLOATING_MAX_WIDTH = 80;
const FLOATING_MIN_HEIGHT = 20;
const FLOATING_MAX_HEIGHT = 40;
const FLOATING_MIN_SPEED = 30;
const FLOATING_MAX_SPEED = 70;
const FLOATING_RANGE_MIN = 100;
const FLOATING_RANGE_MAX = 200;
const DESTRUCTIBLE_MIN_WIDTH = 50;
const DESTRUCTIBLE_MAX_WIDTH = 90;
const DESTRUCTIBLE_MIN_HEIGHT = 30;
const DESTRUCTIBLE_MAX_HEIGHT = 60;
const MOVING_MIN_WIDTH = 60;
const MOVING_MAX_WIDTH = 100;
const MOVING_MIN_HEIGHT = 30;
const MOVING_MAX_HEIGHT = 50;
const MOVING_MIN_SPEED = 40;
const MOVING_MAX_SPEED = 80;
const MOVING_RANGE_MIN = 150;
const MOVING_RANGE_MAX = 250;
const BULLET_RADIUS = 4;

const SCORE_PER_DISTANCE = 0.1;
const COIN_BONUS_PER_KILL = 5;
const COIN_BONUS_PER_DISTANCE = 2; // Coins per 100 units traveled
const COIN_COLLECT_RADIUS = 20;
const WEAPON_UPGRADE_COIN_THRESHOLDS = [10, 25, 50]; // Coin thresholds for weapon upgrades

interface WeaponConfig {
  name: string;
  speed: number;
  radius: number;
  lifetime: number;
  cooldown: number;
  damage: number;
  pierce: number;
  multiShot: number;
  spread: number;
}

const WEAPONS: WeaponConfig[] = [
  {
    name: 'Escopeta',
    speed: 980,
    radius: 4,
    lifetime: 3.5,
    cooldown: 0.28,
    damage: 1,
    pierce: 1,
    multiShot: 1,
    spread: 0,
  },
  {
    name: 'Rifle',
    speed: 1280,
    radius: 3,
    lifetime: 4.5,
    cooldown: 0.16,
    damage: 1,
    pierce: 2,
    multiShot: 1,
    spread: 0,
  },
  {
    name: 'Lanzador',
    speed: 760,
    radius: 7,
    lifetime: 2.8,
    cooldown: 0.42,
    damage: 1,
    pierce: 1,
    multiShot: 1,
    spread: 0,
  },
  {
    name: 'Plasma',
    speed: 1420,
    radius: 5,
    lifetime: 5.0,
    cooldown: 0.12,
    damage: 1,
    pierce: 3,
    multiShot: 2,
    spread: 0.18,
  },
];

const TERRAIN_SEGMENTS = 12;

type Facing = 'left' | 'right';
type ObstacleType = 'crate' | 'spike' | 'enemy' | 'floating' | 'destructible' | 'moving';

interface BossConfig {
  health: number;
  maxHealth: number;
  vx: number;
  healthBarHeight: number;
  color: string;
}

interface Obstacle {
  id: number;
  type: ObstacleType;
  x: number;
  bottom: number;
  width: number;
  height: number;
  scored: boolean;
  speed?: number;
  facing?: Facing;
  vx?: number;
  vy?: number;
  range?: number;
  startX?: number;
  startBottom?: number;
  destructible?: boolean;
  destructibleHp?: number;
  health?: number;
  maxHealth?: number;
  isDead?: boolean;
  bulletDamage?: number;
  bossConfig?: BossConfig;
}

interface Bullet {
  id: number;
  x: number;
  y: number;
  dir: Facing;
  width: number;
  height: number;
  born: number;
}

interface FloatingCoin {
  id: number;
  x: number;
  y: number;
  born: number;
}

interface InitialObstacleSpec {
  type: ObstacleType;
  x: number;
  width: number;
  height: number;
}

interface TerrainSegment {
  id: number;
  x: number;
  width: number;
  bottom: number;
  kind: 'ground' | 'platform' | 'hole';
}

interface ViewState {
  cowScreenX: number;
  cowBottom: number;
  cameraX: number;
  now: number;
  isMoving: boolean;
  isGrounded: boolean;
}

interface GameScreenProps {
  onExit: () => void;
}

interface ObstacleViewProps {
  obstacle: Obstacle;
  left: number;
}

const INITIAL_OBSTACLE_SPECS: InitialObstacleSpec[] = [
  { type: 'crate', x: 300, width: 84, height: 46 },
  { type: 'spike', x: 590, width: 56, height: SPIKE_HEIGHT },
  { type: 'enemy', x: 850, width: ENEMY_WIDTH, height: ENEMY_HEIGHT },
  { type: 'crate', x: 1120, width: 92, height: 52 },
  { type: 'destructible', x: 1400, width: 70, height: 40 },
  { type: 'floating', x: 1700, width: 60, height: 30 },
  { type: 'moving', x: 2000, width: 80, height: 40 },
];

const randomBetween = (min: number, max: number): number =>
  min + Math.random() * (max - min);

const createObstacle = (id: number, x: number, terrainBottom: number = GROUND_HEIGHT): Obstacle => {
  const roll = Math.random();

  if (roll < 0.35) {
    // Caja estándar
    return {
      id,
      type: 'crate',
      x,
      bottom: terrainBottom,
      width: randomBetween(CRATE_MIN_WIDTH, CRATE_MAX_WIDTH),
      height: randomBetween(CRATE_MIN_HEIGHT, CRATE_MAX_HEIGHT),
      scored: false,
    };
  }

  if (roll < 0.55) {
    // Pincho
    return {
      id,
      type: 'spike',
      x,
      bottom: terrainBottom,
      width: randomBetween(SPIKE_MIN_WIDTH, SPIKE_MAX_WIDTH),
      height: SPIKE_HEIGHT,
      scored: false,
    };
  }

  if (roll < 0.70) {
    // Bloque destructible (flotante o en altura)
    const destructibleHeight = randomBetween(DESTRUCTIBLE_MIN_HEIGHT, DESTRUCTIBLE_MAX_HEIGHT);
    return {
      id,
      type: 'destructible',
      x,
      bottom: terrainBottom + randomBetween(0, 60),
      width: randomBetween(DESTRUCTIBLE_MIN_WIDTH, DESTRUCTIBLE_MAX_WIDTH),
      height: destructibleHeight,
      scored: false,
      destructible: true,
      destructibleHp: 1,
    };
  }

  if (roll < 0.82) {
    // Obstáculo móvil (se desplaza en un rango)
    const movingHeight = randomBetween(MOVING_MIN_HEIGHT, MOVING_MAX_HEIGHT);
    return {
      id,
      type: 'moving',
      x,
      bottom: terrainBottom + randomBetween(20, 80),
      width: randomBetween(MOVING_MIN_WIDTH, MOVING_MAX_WIDTH),
      height: movingHeight,
      scored: false,
      speed: randomBetween(MOVING_MIN_SPEED, MOVING_MAX_SPEED),
      facing: Math.random() < 0.5 ? 'left' : 'right',
      range: randomBetween(MOVING_RANGE_MIN, MOVING_RANGE_MAX),
      startX: x,
      startBottom: terrainBottom + randomBetween(20, 80),
      vy: randomBetween(30, 60),
    };
  }

  if (roll < 0.90) {
    // Obstáculo flotante que se mueve verticalmente
    const floatingHeight = randomBetween(FLOATING_MIN_HEIGHT, FLOATING_MAX_HEIGHT);
    return {
      id,
      type: 'floating',
      x,
      bottom: terrainBottom + randomBetween(40, 100),
      width: randomBetween(FLOATING_MIN_WIDTH, FLOATING_MAX_WIDTH),
      height: floatingHeight,
      scored: false,
      vy: randomBetween(FLOATING_MIN_SPEED, FLOATING_MAX_SPEED),
      range: randomBetween(FLOATING_RANGE_MIN, FLOATING_RANGE_MAX),
      startBottom: terrainBottom + randomBetween(40, 100),
    };
  }

  // Monstruo con variaciones de altura y velocidad
  const enemyHeightVariation = randomBetween(0.7, 1.3);
  const enemySpeedVariation = randomBetween(0.6, 1.4);
  const enemyHeight = Math.round(ENEMY_HEIGHT * enemyHeightVariation);

  // Boss spawn: ~5% chance, larger size, more health, boss health bar config
  const isBoss = Math.random() < 0.05;
  if (isBoss) {
    const bossHealth = 8 + Math.floor(Math.random() * 4); // 8-11
    const bossWidth = Math.round(ENEMY_WIDTH * 1.6);
    const bossHeight = Math.round(ENEMY_HEIGHT * 1.6);
    const bossFacing: Facing = Math.random() < 0.5 ? 'left' : 'right';
    const bossSpeed = ENEMY_SPEED * 0.7;
    return {
      id,
      type: 'enemy',
      x,
      bottom: terrainBottom,
      width: bossWidth,
      height: bossHeight,
      scored: false,
      speed: bossSpeed,
      facing: bossFacing,
      vx: bossFacing === 'left' ? -bossSpeed : bossSpeed,
      health: bossHealth,
      maxHealth: bossHealth,
      isDead: false,
      bulletDamage: 1,
      vy: 0,
      bossConfig: {
        health: bossHealth,
        maxHealth: bossHealth,
        vx: bossFacing === 'left' ? -bossSpeed : bossSpeed,
        healthBarHeight: 6,
        color: '#ff3b30',
      },
    };
  }

  const enemyFacing: Facing = Math.random() < 0.5 ? 'left' : 'right';
  const enemySpeed = ENEMY_SPEED * enemySpeedVariation;
  return {
    id,
    type: 'enemy',
    x,
    bottom: terrainBottom,
    width: ENEMY_WIDTH,
    height: enemyHeight,
    scored: false,
    speed: enemySpeed,
    facing: enemyFacing,
    vx: enemyFacing === 'left' ? -enemySpeed : enemySpeed,
    health: 1,
    maxHealth: 1,
    isDead: false,
    bulletDamage: 1,
    vy: 0,
  };
};

const createInitialObstacles = (): Obstacle[] => {
  return INITIAL_OBSTACLE_SPECS.map((spec, index) => {
    const isEnemy = spec.type === 'enemy';
    const enemyFacing: Facing = Math.random() < 0.5 ? 'left' : 'right';

    return {
      id: index + 1,
      type: spec.type,
      x: spec.x,
      bottom: GROUND_HEIGHT,
      width: spec.width,
      height: spec.height,
      scored: false,
      speed: isEnemy ? ENEMY_SPEED : undefined,
      facing: isEnemy ? enemyFacing : undefined,
      vx: isEnemy ? (enemyFacing === 'left' ? -ENEMY_SPEED : ENEMY_SPEED) : undefined,
      vy: isEnemy ? 0 : undefined,
    };
  });
};

const createInitialTerrain = (): TerrainSegment[] => {
  const segments: TerrainSegment[] = [];
  let x = 0;
  let id = 0;
  const MAX_SEGMENTS = 100;

  for (let i = 0; i < TERRAIN_SEGMENTS && segments.length < MAX_SEGMENTS; i++) {
    const width = randomBetween(80, 180);
    segments.push({
      id: id++,
      x,
      width,
      bottom: GROUND_HEIGHT,
      kind: 'ground',
    });
    x += width;
  }

  return segments;
};

interface HasBounds {
  x: number;
  width: number;
}

interface Rect {
  x: number;
  bottom: number;
  width: number;
  height: number;
}

const aabbOverlap = (a: Rect, b: Rect): boolean =>
  a.x < b.x + b.width &&
  a.x + a.width > b.x &&
  a.bottom < b.bottom + b.height &&
  a.bottom + a.height > b.bottom;

const hasHorizontalOverlap = (
  x: number,
  width: number,
  target: HasBounds,
  inset = 0
): boolean =>
  x + width - inset > target.x &&
  x + inset < target.x + target.width;

const getTerrainSupport = (
  x: number,
  width: number,
  terrain: TerrainSegment[]
): number => {
  let support = 0;

  for (const segment of terrain) {
    if (segment.kind === 'hole') {
      continue;
    }

    if (hasHorizontalOverlap(x, width, segment, 6)) {
      if (segment.bottom > support) {
        support = segment.bottom;
      }
    }
  }

  return support;
};

const getTerrainBottomAt = (x: number, terrain: TerrainSegment[]): number => {
  for (const segment of terrain) {
    if (segment.kind === 'hole') {
      continue;
    }
    if (x >= segment.x && x < segment.x + segment.width) {
      return segment.bottom;
    }
  }
  return GROUND_HEIGHT;
};

const getSupportBottom = (
  x: number,
  width: number,
  bottom: number,
  obstacles: Obstacle[]
): number => {
  let support = GROUND_HEIGHT;

  for (const obstacle of obstacles) {
    if (obstacle.type !== 'crate' || !hasHorizontalOverlap(x, width, obstacle, 6)) {
      continue;
    }

    const top = obstacle.bottom + obstacle.height;
    // Only a crate the entity is standing on (or falling onto) can support it.
    if (top > support && bottom >= top - 0.5) {
      support = top;
    }
  }

  return support;
};

const cowRect = (x: number, bottom: number): Rect => ({
  x,
  bottom,
  width: COW_WIDTH,
  height: COW_HEIGHT,
});

const intersectsHazard = (
  x: number,
  bottom: number,
  obstacle: Obstacle
): boolean => aabbOverlap(cowRect(x, bottom), obstacle);

const intersectsEnemy = (
  x: number,
  bottom: number,
  enemy: Obstacle
): boolean => aabbOverlap(cowRect(x, bottom), enemy);

const CrateObstacle = React.memo(function CrateObstacle({
  obstacle,
  left,
}: ObstacleViewProps) {
  const isWood = obstacle.id % 2 === 0;
  const tuftCount = Math.max(3, Math.round(obstacle.width / 22));

  return (
    <View
      style={[
        styles.obstacle,
        isWood ? styles.woodPlatform : styles.stonePlatform,
        {
          left: Number(left),
          bottom: Number(obstacle.bottom),
          width: obstacle.width,
          height: obstacle.height,
        },
      ]}
    >
      {isWood ? (
        <>
          <View style={styles.woodTopHighlight} />
          <View style={styles.woodPlankLineOne} />
          <View style={styles.woodPlankLineTwo} />
          <View style={styles.woodGrainOne} />
          <View style={styles.woodGrainTwo} />
          <View style={styles.woodMoss} />
        </>
      ) : (
        <>
          <View style={styles.stoneShade} />
          <View style={styles.stoneHighlight} />
          <View style={styles.stoneSeamHorizontal} />
          <View style={styles.stoneSeamVertical} />
          <View style={styles.stoneMossLeft} />
          <View style={styles.stoneMossRight} />
        </>
      )}
    </View>
  );
});

const SpikeObstacle = React.memo(function SpikeObstacle({
  obstacle,
  left,
}: {
  obstacle: Obstacle;
  left: number;
}) {
  const spikeWidth = Math.min(24, Math.max(12, obstacle.width / 4));
  const spikeCount = Math.max(1, Math.floor(obstacle.width / spikeWidth));

  return (
    <View
      style={{
        position: 'absolute',
        left: left,
        bottom: obstacle.bottom || 0,
        width: obstacle.width,
        height: obstacle.height,
        flexDirection: 'row',
        alignItems: 'flex-end',
      }}
    >
      {Array.from({ length: spikeCount }).map((_, index) => (
        <View
          key={index}
          style={{
            position: 'relative',
            width: spikeWidth,
            height: obstacle.height,
          }}
        >
          <View
            style={[
              styles.spikeTriangle,
              {
                borderLeftWidth: spikeWidth / 2,
                borderRightWidth: spikeWidth / 2,
                borderBottomWidth: obstacle.height,
              },
            ]}
          />
          <View
            style={[
              styles.spikeHighlight,
              {
                left: spikeWidth / 4,
                borderLeftWidth: spikeWidth / 4,
                borderRightWidth: spikeWidth / 4,
                borderBottomWidth: obstacle.height * 0.58,
              },
            ]}
          />
        </View>
      ))}
    </View>
  );
});

const EnemyObstacle = React.memo(function EnemyObstacle({
  obstacle,
  left,
}: ObstacleViewProps) {
  return (
    <Enemy
      facing={obstacle.facing ?? 'right'}
      width={obstacle.width}
      height={obstacle.height}
      style={[
        styles.obstacle,
        {
          left,
          bottom: obstacle.bottom,
        },
      ]}
    />
  );
});

const DestructibleObstacle = React.memo(function DestructibleObstacle({
  obstacle,
  left,
}: ObstacleViewProps) {
  return (
    <View
      style={[
        styles.obstacle,
        styles.stonePlatform,
        {
          left: Number(left),
          bottom: Number(obstacle.bottom),
          width: obstacle.width,
          height: obstacle.height,
        },
      ]}
    >
      <View style={styles.stoneShade} />
      <View style={styles.stoneHighlight} />
      <View style={styles.stoneSeamHorizontal} />
      <View style={styles.stoneMossLeft} />
      <View style={styles.destructibleCrack} />
      <View style={styles.destructibleCrackSmall} />
    </View>
  );
});

const MovingObstacle = React.memo(function MovingObstacle({
  obstacle,
  left,
}: ObstacleViewProps) {
  return (
    <View
      style={[
        styles.obstacle,
        styles.woodPlatform,
        {
          left: Number(left),
          bottom: Number(obstacle.bottom),
          width: obstacle.width,
          height: obstacle.height,
        },
      ]}
    >
      <View style={styles.woodTopHighlight} />
      <View style={styles.woodPlankLineOne} />
      <View style={styles.woodPlankLineTwo} />
      <View style={styles.woodGrainOne} />
      <View style={styles.woodMoss} />
    </View>
  );
});

const FloatingObstacle = React.memo(function FloatingObstacle({
  obstacle,
  left,
}: ObstacleViewProps) {
  return (
    <View
      style={[
        styles.obstacle,
        styles.woodPlatform,
        {
          left: Number(left),
          bottom: Number(obstacle.bottom),
          width: obstacle.width,
          height: obstacle.height,
        },
      ]}
    >
      <View style={styles.woodTopHighlight} />
      <View style={styles.woodPlankLineOne} />
      <View style={styles.woodPlankLineTwo} />
      <View style={styles.woodGrainOne} />
      <View style={styles.woodGrainTwo} />
      <View style={styles.woodMoss} />
      <View style={styles.floatingGlow} />
    </View>
  );
});

interface CloudData {
  id: number;
  x: number;
  y: number;
  speed: number;
  width: number;
  height: number;
  opacity: number;
}

const SKY_BANDS = [
  '#2f7fc1',
  '#3d90cf',
  '#52a4dc',
  '#6db9e7',
  '#8fcef0',
  '#b6e2f7',
  '#dcf3fc',
];

const Landscape = React.memo(function Landscape() {
  return (
    <View pointerEvents="none" style={styles.landscape}>
      {SKY_BANDS.map((color, index) => (
        <View
          key={`${color}-${index}`}
          style={[styles.skyBand, { backgroundColor: color }]}
        />
      ))}
      
      <View style={styles.sunHalo} />
      <View style={styles.sun} />

      <View style={[styles.hill, styles.hillFarOne]} />
      <View style={[styles.hill, styles.hillFarTwo]} />
      <View style={[styles.hill, styles.hillMidOne]} />
      <View style={[styles.hill, styles.hillMidTwo]} />

      <View style={styles.horizonHaze} />

      <View style={styles.forestRow}>
        {Array.from({ length: 18 }).map((_, index) => (
          <View key={index} style={styles.tree}>
            <View style={styles.treeFoliage} />
            <View style={styles.treeTrunk} />
          </View>
        ))}
      </View>
    </View>
  );
});

const Cloud = React.memo(function Cloud({
  cloud,
  cameraX,
}: {
  cloud: CloudData;
  cameraX: number;
}) {
  return (
    <View
      pointerEvents="none"
      style={[
        styles.cloud,
        {
          left: Number(cloud.x - cameraX),
          bottom: Number(cloud.y),
          width: cloud.width,
          height: cloud.height,
          opacity: cloud.opacity,
        },
      ]}
    >
      <View
        style={[
          styles.cloudPuff,
          {
            left: cloud.width * 0.55,
            bottom: 0,
            width: cloud.width * 0.5,
            height: cloud.height,
          },
        ]}
      />
      <View
        style={[
          styles.cloudPuff,
          {
            left: cloud.width * 0.2,
            bottom: cloud.height * 0.15,
            width: cloud.width * 0.7,
            height: cloud.height * 1.35,
          },
        ]}
      />
      <View
        style={[
          styles.cloudPuff,
          {
            right: 0,
            bottom: 0,
            width: cloud.width * 0.5,
            height: cloud.height,
          },
        ]}
      />
    </View>
  );
});

const FloatingCoinComponent = React.memo(function FloatingCoinComponent({
  coin,
  cameraX,
  now,
}: {
  coin: FloatingCoin;
  cameraX: number;
  now: number;
}) {
  const age = Math.max(0, now - coin.born);
  const opacity = Math.max(0, 1 - age / 2.5);
  const rise = age * 18;
  const bob = Math.sin(now * 5 + coin.id) * 3;
  const scale = 1 + Math.sin(now * 7 + coin.id) * 0.08;

  return (
    <>
      <View
        style={[
          styles.coinHalo,
          {
            left: Number(coin.x - cameraX - 17),
            bottom: Number(coin.y + rise + bob - 7),
            opacity,
          },
        ]}
      />
      <View
        style={[
          styles.coin,
          {
            left: Number(coin.x - cameraX - 10),
            bottom: Number(coin.y + rise + bob),
            opacity,
            transform: [{ scale }],
          },
        ]}
      />
    </>
  );
});

export const GameScreen: React.FC<GameScreenProps> = ({ onExit }) => {
  const screenWidth =
    Number.isFinite(SCREEN_WIDTH) && SCREEN_WIDTH > 0
      ? SCREEN_WIDTH
      : FALLBACK_SCREEN_WIDTH;
  const screenHeight =
    Number.isFinite(SCREEN_HEIGHT) && SCREEN_HEIGHT > 0
      ? SCREEN_HEIGHT
      : FALLBACK_SCREEN_HEIGHT;

  const [obstacles, setObstacles] = useState<Obstacle[]>(createInitialObstacles);
  const [terrain, setTerrain] = useState<TerrainSegment[]>(createInitialTerrain);
  const [bullets, setBullets] = useState<Bullet[]>([]);
  const [floatingCoins, setFloatingCoins] = useState<FloatingCoin[]>([]);
  const [clouds, setClouds] = useState<CloudData[]>([]);
  const cloudsRef = useRef<CloudData[]>([]);
  const [view, setView] = useState<ViewState>({
    cowScreenX: PLAYER_START_X,
    cowBottom: GROUND_HEIGHT,
    cameraX: 0,
    now: 0,
    isMoving: false,
    isGrounded: true,
  });
  const [facing, setFacing] = useState<Facing>('right');
  const [score, setScore] = useState(0);
  const [coins, setCoins] = useState(0);
  const [bestScore, setBestScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [currentWeapon, setCurrentWeapon] = useState(0);
  const [deathEffects, setDeathEffects] = useState<
    { x: number; y: number; born: number; id: number }[]
  >([]);
  const cowXRef = useRef(PLAYER_START_X);
  const cowBottomRef = useRef(GROUND_HEIGHT);
  const cameraXRef = useRef(0);
  const velocityXRef = useRef(0);
  const velocityYRef = useRef(0);
  const isGroundedRef = useRef(true);
  const leftHeldRef = useRef(false);
  const rightHeldRef = useRef(false);
  const isPressingLeftRef = useRef(false);
  const isPressingRightRef = useRef(false);
  const isMovingRightRef = useRef(false);
  const isMovingLeftRef = useRef(false);
  const obstaclesRef = useRef<Obstacle[]>(obstacles);
  const terrainRef = useRef<TerrainSegment[]>(terrain);
  const bulletsRef = useRef<Bullet[]>([]);
  const floatingCoinsRef = useRef<FloatingCoin[]>([]);
  const bulletIdRef = useRef(0);
  const lastShotRef = useRef(0);
  const scoreRef = useRef(0);
  const coinsRef = useRef(0);
  const weaponRef = useRef(0);
  const lastDistanceScoredRef = useRef(0);
  const nextObstacleXRef = useRef(INITIAL_NEXT_OBSTACLE_X);
  const obstacleIdRef = useRef(obstacles.length);
  const gameOverRef = useRef(false);
  const startLoopRef = useRef<(() => void) | null>(null);
  const deathEffectsRef = useRef<{ x: number; y: number; born: number; id: number }[]>([]);
  const deathEffectIdRef = useRef(0);

  const checkWeaponUpgrade = (currentCoins: number) => {
    let targetWeaponIndex = 0;
    for (let i = 0; i < WEAPON_UPGRADE_COIN_THRESHOLDS.length; i++) {
      if (currentCoins >= WEAPON_UPGRADE_COIN_THRESHOLDS[i]) {
        targetWeaponIndex = Math.min(WEAPONS.length - 1, i + 1);
      }
    }
    if (targetWeaponIndex > weaponRef.current) {
      weaponRef.current = targetWeaponIndex;
      setCurrentWeapon(targetWeaponIndex);
    }
  };

  useEffect(() => {
    let frameId = 0;
    let running = false;
    let lastTime = 0;
    let renderElapsed = 0;

    const spawnCloud = () => {
      const id = cloudsRef.current.length + 1;
      const x = cameraXRef.current + screenWidth + randomBetween(50, 300);
      const y = randomBetween(screenHeight * 0.25, screenHeight * 0.8);
      const speed = randomBetween(10, 35);
      const width = randomBetween(60, 140);
      const height = randomBetween(20, 50);
      const opacity = randomBetween(0.4, 0.8);
      return { id, x, y, speed, width, height, opacity };
    };

    if (cloudsRef.current.length === 0) {
      const initialClouds = Array.from({ length: 6 }, spawnCloud);
      cloudsRef.current = initialClouds;
      setClouds([...initialClouds]);
    }

    const updateView = () => {
      setView({
        cowScreenX: cowXRef.current - cameraXRef.current,
        cowBottom: cowBottomRef.current,
        cameraX: cameraXRef.current,
        now: performance.now() / 1000,
        isMoving: isMovingRightRef.current || isMovingLeftRef.current,
        isGrounded: isGroundedRef.current,
      });
    };

    const triggerGameOver = () => {
      if (gameOverRef.current) {
        return;
      }

      gameOverRef.current = true;
      velocityXRef.current = 0;
      velocityYRef.current = 0;
      leftHeldRef.current = false;
      rightHeldRef.current = false;
      isMovingRightRef.current = false;
      isMovingLeftRef.current = false;
      isPressingLeftRef.current = false;
      isPressingRightRef.current = false;
      setGameOver(true);
      setBestScore((currentBest) => Math.max(currentBest, scoreRef.current));
    };

    const loop = (time: number) => {
      if (!running) {
        return;
      }

      const delta =
        lastTime === 0
          ? 0
          : Math.max(0, Math.min((time - lastTime) / 1000, 0.05));
      lastTime = time;

      if (gameOverRef.current) {
        running = false;
        return;
      }

      // Persistent directional state: the jump must never cancel horizontal
      // velocity while a direction button is still held. When no direction
      // is active, force a full stop so the cow never keeps walking alone.
      if (isMovingRightRef.current) {
        velocityXRef.current = !isGroundedRef.current ? AIR_MOVE_SPEED : MOVE_SPEED;
      } else if (isMovingLeftRef.current) {
        velocityXRef.current = !isGroundedRef.current ? -AIR_MOVE_SPEED : -MOVE_SPEED;
      } else {
        velocityXRef.current = 0;
      }

      const velocityX = velocityXRef.current;

      if (velocityX !== 0) {
        let nextX = cowXRef.current + velocityX * delta;

        for (const obstacle of obstaclesRef.current) {
          if (obstacle.type !== 'crate') {
            continue;
          }

          const crateTop = obstacle.bottom + obstacle.height;
          const overlapsVertically =
            cowBottomRef.current < crateTop &&
            cowBottomRef.current + COW_HEIGHT > obstacle.bottom;

          if (!overlapsVertically) {
            continue;
          }

          if (
            velocityX > 0 &&
            nextX + COW_WIDTH > obstacle.x &&
            nextX < obstacle.x + obstacle.width
          ) {
            nextX = Math.min(nextX, obstacle.x - COW_WIDTH);
          } else if (
            velocityX < 0 &&
            nextX < obstacle.x + obstacle.width &&
            nextX + COW_WIDTH > obstacle.x
          ) {
            nextX = Math.max(nextX, obstacle.x + obstacle.width);
          }
        }

        cowXRef.current = Math.max(0, nextX);
      }

      if (isGroundedRef.current) {
        const supportBottom = Math.max(
          getTerrainSupport(cowXRef.current, COW_WIDTH, terrainRef.current),
          getSupportBottom(
            cowXRef.current,
            COW_WIDTH,
            cowBottomRef.current,
            obstaclesRef.current
          )
        );

        if (supportBottom >= cowBottomRef.current - 0.5) {
          cowBottomRef.current = supportBottom;
          velocityYRef.current = 0;
        } else {
          isGroundedRef.current = false;
        }
      }

      if (!isGroundedRef.current) {
        const previousBottom = cowBottomRef.current;
        const isApex =
          Math.abs(velocityYRef.current) <= APEX_VELOCITY_THRESHOLD &&
          velocityYRef.current > -MAX_FALL_SPEED * 0.5;
        const gravity = isApex
          ? GRAVITY * APEX_GRAVITY_FACTOR
          : GRAVITY;

        velocityYRef.current = Math.max(
          velocityYRef.current - gravity * delta,
          -MAX_FALL_SPEED
        );

        let nextBottom = previousBottom + velocityYRef.current * delta;
        let landingBottom: number | null = null;

        if (velocityYRef.current <= 0) {
          // Check terrain support (platforms)
          for (const segment of terrainRef.current) {
            if (segment.kind === 'hole') {
              continue;
            }

            if (!hasHorizontalOverlap(cowXRef.current, COW_WIDTH, segment, 6)) {
              continue;
            }

            const segmentTop = segment.bottom;

            if (
              previousBottom >= segmentTop - 1 &&
              nextBottom <= segmentTop + 0.5
            ) {
              if (landingBottom === null || segmentTop > landingBottom) {
                landingBottom = segmentTop;
              }
            }
          }

          // Check crate support
          for (const obstacle of obstaclesRef.current) {
            if (
              obstacle.type !== 'crate' ||
              !hasHorizontalOverlap(cowXRef.current, COW_WIDTH, obstacle, 6)
            ) {
              continue;
            }

            const crateTop = obstacle.bottom + obstacle.height;

            if (
              previousBottom >= crateTop - 1 &&
              nextBottom <= crateTop + 0.5
            ) {
              if (landingBottom === null || crateTop > landingBottom) {
                landingBottom = crateTop;
              }
            }
          }

          if (nextBottom <= GROUND_HEIGHT) {
            if (landingBottom === null || GROUND_HEIGHT > landingBottom) {
              landingBottom = GROUND_HEIGHT;
            }
          }

          if (landingBottom !== null) {
            nextBottom = landingBottom;
            velocityYRef.current = 0;
            isGroundedRef.current = true;
          }

          cowBottomRef.current = nextBottom;
        }
      }

      // Patrol enemies horizontally with strict AABB collision and gravity.
      for (const obstacle of obstaclesRef.current) {
        if (obstacle.type !== 'enemy') {
          continue;
        }

        const baseSpeed = obstacle.speed ?? ENEMY_SPEED;
        if (!obstacle.vx) {
          obstacle.vx = obstacle.facing === 'left' ? -baseSpeed : baseSpeed;
        }

        const nextX = obstacle.x + obstacle.vx * delta;
        const nextRect: Rect = {
          x: nextX,
          bottom: obstacle.bottom,
          width: obstacle.width,
          height: obstacle.height,
        };

        let blocked = false;
        for (const other of obstaclesRef.current) {
          if (other.id === obstacle.id || other.type === 'enemy') {
            continue;
          }
          if (aabbOverlap(nextRect, other)) {
            blocked = true;
            break;
          }
        }

        if (blocked) {
          // Reverse the horizontal velocity when a solid obstacle is hit.
          obstacle.vx *= -1;
        } else {
          obstacle.x = nextX;
        }

        // World bounds: bounce back if the monster reaches the left edge.
        if (obstacle.x < 0) {
          obstacle.x = 0;
          obstacle.vx = Math.abs(obstacle.vx);
        }

        // Keep the patrol anchored around the player.
        const patrolRange = obstacle.bossConfig
          ? ENEMY_PATROL_RANGE * 2
          : ENEMY_PATROL_RANGE;
        if (obstacle.x < cowXRef.current - patrolRange) {
          obstacle.vx = Math.abs(obstacle.vx);
        } else if (obstacle.x > cowXRef.current + patrolRange) {
          obstacle.vx = -Math.abs(obstacle.vx);
        }

        obstacle.facing = obstacle.vx < 0 ? 'left' : 'right';
        if (obstacle.bossConfig) {
          obstacle.bossConfig.vx = obstacle.vx;
        }

        // Gravity: enemies fall until resting on the ground or on a crate.
        const supportBottom = Math.max(
          getTerrainSupport(obstacle.x, obstacle.width, terrainRef.current),
          getSupportBottom(
            obstacle.x,
            obstacle.width,
            obstacle.bottom,
            obstaclesRef.current
          )
        );

        if (obstacle.bottom <= supportBottom + 0.5) {
          obstacle.bottom = supportBottom;
          obstacle.vy = 0;
        } else {
          const vy = (obstacle.vy ?? 0) - GRAVITY * delta;
          obstacle.vy = Math.max(vy, -MAX_FALL_SPEED);
          obstacle.bottom += obstacle.vy * delta;
          if (obstacle.bottom <= supportBottom) {
            obstacle.bottom = supportBottom;
            obstacle.vy = 0;
          }
        }
      }

      // Update moving and floating obstacles
      for (const obstacle of obstaclesRef.current) {
        if (obstacle.type === 'moving' && obstacle.speed && obstacle.range && obstacle.startX !== undefined) {
          const dir = obstacle.facing === 'left' ? -1 : 1;
          obstacle.x += dir * obstacle.speed * delta;

          if (Math.abs(obstacle.x - obstacle.startX) >= obstacle.range) {
            obstacle.facing = obstacle.facing === 'left' ? 'right' : 'left';
          }
        }

        if (obstacle.type === 'floating' && obstacle.vy && obstacle.range && obstacle.startBottom !== undefined) {
          obstacle.bottom += obstacle.vy * delta;

          if (Math.abs(obstacle.bottom - obstacle.startBottom) >= obstacle.range) {
            obstacle.vy *= -1;
          }
        }
      }

      // Update bullets: move them and resolve collisions with obstacles.
      if (bulletsRef.current.length > 0) {
        const weapon = WEAPONS[currentWeapon];
        for (const bullet of bulletsRef.current) {
          const dir = bullet.dir === 'right' ? 1 : -1;
          bullet.x += dir * weapon.speed * delta;
        }

        const remainingBullets: Bullet[] = [];
        for (const bullet of bulletsRef.current) {
          const bulletRect: Rect = {
            x: bullet.x,
            bottom: bullet.y,
            width: bullet.width,
            height: bullet.height,
          };

          let hitObstacle: Obstacle | null = null;

          for (const obstacle of obstaclesRef.current) {
            if (aabbOverlap(bulletRect, obstacle)) {
              hitObstacle = obstacle;
              break;
            }
          }

          if (hitObstacle) {
            const isDestroyable =
              hitObstacle.type === 'enemy' ||
              hitObstacle.type === 'destructible' ||
              hitObstacle.type === 'moving';

            if (isDestroyable) {
              const now = performance.now() / 1000;
              const currentHealth = hitObstacle.health ?? 1;
              const bulletDamage = weapon.damage ?? 1;
              const newHealth = currentHealth - bulletDamage;

              // Spawn death effect at enemy position
              deathEffectIdRef.current += 1;
              deathEffectsRef.current.push({
                id: deathEffectIdRef.current,
                x: hitObstacle.x + hitObstacle.width / 2,
                y: hitObstacle.bottom + hitObstacle.height / 2,
                born: now,
              });

              if (newHealth <= 0) {
                // Mark dead and remove from obstacles
                hitObstacle.isDead = true;
                obstaclesRef.current = obstaclesRef.current.filter(
                  (o) => o.id !== hitObstacle.id
                );
                // Forzar re-render de la UI con el nuevo estado de obstáculos
                setObstacles([...obstaclesRef.current]);

                // Spawneo directo de moneda en las coordenadas exactas del monstruo
                floatingCoinsRef.current.push({
                  id: Date.now(),
                  x: hitObstacle.x + hitObstacle.width / 2,
                  y: hitObstacle.bottom + hitObstacle.height / 2,
                  born: now,
                });
                setFloatingCoins([...floatingCoinsRef.current]);

                // Award points and coins for each kill
                scoreRef.current += 1;
                setScore(scoreRef.current);
                coinsRef.current += COIN_BONUS_PER_KILL;
                setCoins(coinsRef.current);
                checkWeaponUpgrade(coinsRef.current);
              } else {
                // Enemy survives with reduced health; mutate the ref entry in place
                const idx = obstaclesRef.current.findIndex(
                  (o) => o.id === hitObstacle.id
                );
                if (idx !== -1) {
                  obstaclesRef.current[idx].health = newHealth;
                }
                setObstacles([...obstaclesRef.current]);
              }
            }
            // La bala que impactó se filtra y elimina (no se empuja a remainingBullets)
            continue;
          }

          if (
            bullet.x < cameraXRef.current - 80 ||
            bullet.x + bullet.width > cameraXRef.current + screenWidth + 80 ||
            time - bullet.born > weapon.lifetime
          ) {
            continue;
          }

          remainingBullets.push(bullet);
        }

        bulletsRef.current = remainingBullets;
        setBullets([...remainingBullets]);
      }

      // Clean up old floating coins
      const now = performance.now() / 1000;
      floatingCoinsRef.current = floatingCoinsRef.current.filter(
        (coin) => now - coin.born < 2.5
      );
      setFloatingCoins([...floatingCoinsRef.current]);

      // Clean up old death effects
      deathEffectsRef.current = deathEffectsRef.current.filter(
        (effect) => now - effect.born < 0.6
      );
      setDeathEffects([...deathEffectsRef.current]);

      cameraXRef.current = Math.max(0, cowXRef.current - CAMERA_OFFSET_X);

      // Parallax clouds
      const cloudSpeedFactor = 0.05;
      const updatedClouds = cloudsRef.current.map((cloud) => ({
        ...cloud,
        x: cloud.x - cloud.speed * delta * cloudSpeedFactor,
      }));

      const regeneratedClouds = updatedClouds.map((cloud) => {
        if (cloud.x + cloud.width < cameraXRef.current - 100) {
          return {
            ...cloud,
            x: cameraXRef.current + screenWidth + randomBetween(50, 300),
            y: randomBetween(screenHeight * 0.25, screenHeight * 0.8),
            opacity: randomBetween(0.4, 0.8),
          };
        }
        return cloud;
      });

      cloudsRef.current = regeneratedClouds;
      setClouds([...regeneratedClouds]);

      // Player vs patrolling enemy collision (AABB).
      for (const obstacle of obstaclesRef.current) {
        if (obstacle.type !== 'enemy') {
          continue;
        }

        if (intersectsEnemy(cowXRef.current, cowBottomRef.current, obstacle)) {
          triggerGameOver();
          break;
        }
      }

      // Only spikes are lethal obstacles; platforms and crates are safe.
      for (const obstacle of obstaclesRef.current) {
        if (obstacle.type !== 'spike') {
          continue;
        }

        if (intersectsHazard(cowXRef.current, cowBottomRef.current, obstacle)) {
          triggerGameOver();
          break;
        }
      }

      if (gameOverRef.current) {
        updateView();
        running = false;
        return;
      }

      for (const obstacle of obstaclesRef.current) {
        if (!obstacle.scored && obstacle.x + obstacle.width < cowXRef.current) {
          obstacle.scored = true;
          scoreRef.current += 1;
          setScore(scoreRef.current);
        }
      }

      // Score by distance traveled
      const currentDistance = Math.max(0, cowXRef.current - lastDistanceScoredRef.current);
      if (currentDistance >= 100) {
        const distancePoints = Math.floor(currentDistance * SCORE_PER_DISTANCE);
        scoreRef.current += distancePoints;
        setScore(scoreRef.current);
        lastDistanceScoredRef.current = cowXRef.current;

        // Award coins for distance traveled
        const distanceCoins = Math.floor(currentDistance / 100) * COIN_BONUS_PER_DISTANCE;
        if (distanceCoins > 0) {
          coinsRef.current += distanceCoins;
          setCoins(coinsRef.current);
          checkWeaponUpgrade(coinsRef.current);
        }
      }

      // Collect floating coins (AABB collision with cow)
      const cowLeft = cowXRef.current;
      const cowRight = cowXRef.current + COW_WIDTH;
      const cowTop = cowBottomRef.current;
      const cowBottom = cowBottomRef.current + COW_HEIGHT;

      let coinsCollected = 0;
      const remainingCoins = floatingCoinsRef.current.filter((coin) => {
        const r = COIN_COLLECT_RADIUS;
        const coinLeft = coin.x - r;
        const coinRight = coin.x + r;
        const coinTop = coin.y - r;
        const coinBottom = coin.y + r;

        if (
          cowLeft < coinRight &&
          cowRight > coinLeft &&
          cowTop < coinBottom &&
          cowBottom > coinTop
        ) {
          coinsCollected += 1;
          return false; // Remove collected coin
        }
        return true;
      });

      floatingCoinsRef.current = remainingCoins;
      setFloatingCoins([...remainingCoins]);

      if (coinsCollected > 0) {
        coinsRef.current += coinsCollected;
        setCoins(coinsRef.current);
        checkWeaponUpgrade(coinsRef.current);
      }

      let generatedObstacle = false;

      while (
        nextObstacleXRef.current <
        cameraXRef.current + screenWidth + GENERATION_AHEAD
      ) {
        const lastObstacleX = obstaclesRef.current.length > 0
          ? Math.max(...obstaclesRef.current.map((o) => o.x))
          : 0;

        if (nextObstacleXRef.current - lastObstacleX < SPAWN_GAP) {
          nextObstacleXRef.current = lastObstacleX + SPAWN_GAP;
          continue;
        }

        const terrainBottom = getTerrainBottomAt(
          nextObstacleXRef.current,
          terrainRef.current
        );
        obstacleIdRef.current += 1;
        const newObstacle = createObstacle(
          obstacleIdRef.current,
          nextObstacleXRef.current,
          terrainBottom
        );
        obstaclesRef.current.push(newObstacle);

        // Extra spacing after enemies so they don't spawn glued to crates/spikes
        if (newObstacle.type === 'enemy') {
          nextObstacleXRef.current += SPAWN_GAP;
        } else {
          nextObstacleXRef.current += randomBetween(
            OBSTACLE_GAP_MIN,
            OBSTACLE_GAP_MAX
          );
        }
        generatedObstacle = true;
      }

      // Generate terrain segments ahead of the camera
      let generatedTerrain = false;
      const lastTerrain = terrainRef.current[terrainRef.current.length - 1];
      let terrainEnd = lastTerrain ? lastTerrain.x + lastTerrain.width : 0;
      const targetEnd = cameraXRef.current + screenWidth + GENERATION_AHEAD;
      const MAX_TERRAIN_SEGMENTS = 100;

      while (terrainEnd < targetEnd && terrainRef.current.length < MAX_TERRAIN_SEGMENTS) {
        const width = randomBetween(80, 180);
        terrainRef.current.push({
          id: terrainRef.current.length,
          x: terrainEnd,
          width,
          bottom: GROUND_HEIGHT,
          kind: 'ground',
        });
        terrainEnd += width;
        generatedTerrain = true;
      }

      // Clean up terrain segments that are far behind the camera
      const cleanupThreshold = cameraXRef.current - 200;
      terrainRef.current = terrainRef.current.filter(
        (segment) => segment.x + segment.width > cleanupThreshold
      );

      if (generatedObstacle) {
        setObstacles([...obstaclesRef.current]);
      }
      if (generatedTerrain) {
        setTerrain([...terrainRef.current]);
      }

      // Check for weapon upgrade based on coins
      checkWeaponUpgrade(coinsRef.current);

      renderElapsed += delta;
      if (renderElapsed >= RENDER_INTERVAL) {
        updateView();
        renderElapsed = 0;
      }

      frameId = requestAnimationFrame(loop);
    };

    const start = () => {
      if (running) {
        return;
      }

      running = true;
      lastTime = 0;
      frameId = requestAnimationFrame(loop);
    };

    startLoopRef.current = start;
    start();
  }, [screenHeight, screenWidth]);

  const requestStart = useCallback(() => {
    startLoopRef.current?.();
  }, []);

  const updateHorizontalVelocity = useCallback(() => {
    if (gameOverRef.current) {
      velocityXRef.current = 0;
      return;
    }

    if (leftHeldRef.current === rightHeldRef.current) {
      // No direction held: stop instantly on the ground, but keep air
      // inertia in the loop instead of cutting momentum abruptly.
      if (isGroundedRef.current) {
        velocityXRef.current = 0;
      }
      return;
    }

    const targetSpeed = !isGroundedRef.current ? AIR_MOVE_SPEED : MOVE_SPEED;
    velocityXRef.current = leftHeldRef.current ? -targetSpeed : targetSpeed;
  }, []);

  const handleLeftPressIn = useCallback(() => {
    if (gameOverRef.current) {
      return;
    }

    isPressingLeftRef.current = true;
    isMovingLeftRef.current = true;
    leftHeldRef.current = true;
    setFacing('left');
    updateHorizontalVelocity();
    requestStart();
  }, [requestStart, updateHorizontalVelocity]);

  const handleLeftPressOut = useCallback(() => {
    isPressingLeftRef.current = false;
    isMovingLeftRef.current = false;
    leftHeldRef.current = false;
    updateHorizontalVelocity();
  }, [updateHorizontalVelocity]);

  const handleRightPressIn = useCallback(() => {
    if (gameOverRef.current) {
      return;
    }

    isPressingRightRef.current = true;
    isMovingRightRef.current = true;
    rightHeldRef.current = true;
    setFacing('right');
    updateHorizontalVelocity();
    requestStart();
  }, [requestStart, updateHorizontalVelocity]);

  const handleRightPressOut = useCallback(() => {
    isPressingRightRef.current = false;
    isMovingRightRef.current = false;
    rightHeldRef.current = false;
    updateHorizontalVelocity();
  }, [updateHorizontalVelocity]);

  const handleJumpPressIn = useCallback(() => {
    if (gameOverRef.current || !isGroundedRef.current) {
      return;
    }

    velocityYRef.current = JUMP_SPEED;
    isGroundedRef.current = false;
    requestStart();
  }, [requestStart]);

  const shoot = useCallback(() => {
    if (gameOverRef.current) {
      return;
    }

    const weapon = WEAPONS[weaponRef.current];
    const now = performance.now() / 1000;
    if (now - lastShotRef.current < weapon.cooldown) {
      return;
    }

    lastShotRef.current = now;

    const muzzleX =
      facing === 'right'
        ? cowXRef.current + COW_WIDTH
        : cowXRef.current - BULLET_RADIUS * 2;
    const muzzleY = cowBottomRef.current + COW_HEIGHT * 0.5;

    // Multi-shot: fire multiple projectiles with spread
    for (let i = 0; i < weapon.multiShot; i++) {
      const spreadOffset =
        weapon.multiShot > 1
          ? (i - (weapon.multiShot - 1) / 2) * weapon.spread
          : 0;

      bulletIdRef.current += 1;
      const bullet: Bullet = {
        id: bulletIdRef.current,
        x: muzzleX + spreadOffset * 50,
        y: muzzleY + spreadOffset * 20,
        dir: facing,
        width: BULLET_RADIUS * 2,
        height: BULLET_RADIUS * 2,
        born: now,
      };

      bulletsRef.current.push(bullet);
    }

    setBullets([...bulletsRef.current]);
    requestStart();
  }, [facing, requestStart]);

  const handleShootPressIn = useCallback(() => {
    shoot();
  }, [shoot]);

  // Keyboard controls for PC/Web
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (gameOverRef.current) {
        return;
      }

      switch (event.key) {
        case 'ArrowLeft':
        case 'a':
        case 'A':
          event.preventDefault();
          handleLeftPressIn();
          break;
        case 'ArrowRight':
        case 'd':
        case 'D':
          event.preventDefault();
          handleRightPressIn();
          break;
        case ' ':
        case 'ArrowUp':
        case 'w':
        case 'W':
          event.preventDefault();
          handleJumpPressIn();
          break;
        case 'f':
        case 'F':
          event.preventDefault();
          handleShootPressIn();
          break;
      }
    };

    const handleKeyUp = (event: KeyboardEvent) => {
      switch (event.key) {
        case 'ArrowLeft':
        case 'a':
        case 'A':
          handleLeftPressOut();
          break;
        case 'ArrowRight':
        case 'd':
        case 'D':
          handleRightPressOut();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [handleLeftPressIn, handleLeftPressOut, handleRightPressIn, handleRightPressOut, handleJumpPressIn, handleShootPressIn]);

  const restart = useCallback(() => {
    const initialObstacles = createInitialObstacles();
    const initialTerrain = createInitialTerrain();

    cowXRef.current = PLAYER_START_X;
    cowBottomRef.current = GROUND_HEIGHT;
    cameraXRef.current = 0;
    velocityXRef.current = 0;
    velocityYRef.current = 0;
    isGroundedRef.current = true;
    leftHeldRef.current = false;
    rightHeldRef.current = false;
    isMovingRightRef.current = false;
    isMovingLeftRef.current = false;
    isPressingLeftRef.current = false;
    isPressingRightRef.current = false;
    obstaclesRef.current = initialObstacles;
    terrainRef.current = initialTerrain;
    bulletsRef.current = [];
    bulletIdRef.current = 0;
    lastShotRef.current = 0;
    scoreRef.current = 0;
    coinsRef.current = 0;
    weaponRef.current = 0;
    lastDistanceScoredRef.current = 0;
    nextObstacleXRef.current = INITIAL_NEXT_OBSTACLE_X;
    obstacleIdRef.current = initialObstacles.length;
    gameOverRef.current = false;

    setObstacles(initialObstacles);
    setTerrain(initialTerrain);
    setView({
      cowScreenX: PLAYER_START_X,
      cowBottom: GROUND_HEIGHT,
      cameraX: 0,
      now: performance.now() / 1000,
      isMoving: false,
      isGrounded: true,
    });
    setFacing('right');
    setScore(0);
    setCoins(0);
  }, []);


  const visibleObstacles = obstacles.filter(obs => obs.x + obs.width > view.cameraX && obs.x < view.cameraX + screenWidth);
  const visibleBullets = bullets.filter(b => b.x + 5 > view.cameraX && b.x - 5 < view.cameraX + screenWidth);
  return (
    <View style={styles.container}>
      {/* Illustrated landscape: gradient sky, sun, hills and forest */}
      <Landscape />

   {/* Obstáculos con Skia */}
{Array.isArray(visibleObstacles) && visibleObstacles.map((obstacle) => {
  const left = Number(obstacle.x - view.cameraX);
  
  // Calculamos la 'y' basada en la altura del suelo y del obstáculo
  const obstacleWithY = {
    ...obstacle,
    y: screenHeight - GROUND_HEIGHT - obstacle.height - (obstacle.bottom || 0),
  };

  return (
    <SkiaObstacles 
      key={obstacle.id} 
      obstacles={[obstacleWithY]} 
      left={left} 
    />
  );
})}
      {visibleBullets.map((bullet) => (
        <View
          key={bullet.id}
          style={[
            styles.bullet,
            {
              left: Number(bullet.x - view.cameraX - BULLET_RADIUS),
              bottom: Number(bullet.y - BULLET_RADIUS),
            },
          ]}
        />
      ))}

      {floatingCoins.map((coin) => (
        <FloatingCoinComponent
          key={coin.id}
          coin={coin}
          cameraX={view.cameraX}
          now={view.now}
        />
      ))}

      {deathEffects.map((effect) => {
        const age = Math.max(0, view.now - effect.born);
        const opacity = Math.max(0, 1 - age / 0.6);
        const scale = Math.max(0.3, 1 - age / 0.6);
        const left = Number(effect.x - view.cameraX - 12);
        const bottom = Number(effect.y + 16);
        return (
          <View
            key={effect.id}
            style={[
              styles.deathEffect,
              {
                left,
                bottom,
                opacity,
                transform: [{ scale }],
              },
            ]}
          >
            <View style={styles.deathParticle} />
            <View style={[styles.deathParticle, { left: 6 }]} />
            <View style={[styles.deathParticle, { left: 12 }]} />
          </View>
        );
      })}

      <Cow
        facing={facing}
        width={COW_WIDTH}
        height={COW_HEIGHT}
        isMoving={view.isMoving}
        isJumping={!view.isGrounded}
        style={[
          styles.cow,
          {
            left: Number(view.cowScreenX),
            bottom: Number(view.cowBottom),
          },
        ]}
      />

      <CurrentScore score={score} />

      {/* Weapon and coins HUD */}
      <View style={styles.hud}>
        <View style={styles.hudWeapon}>
          <View
            style={[
              styles.hudWeaponRow,
              {
                borderLeftWidth: currentWeapon > 0 ? 4 : 0,
                borderLeftColor: currentWeapon > 0 ? '#ffe14d' : 'transparent',
              },
            ]}
          >
            <Text
              style={[
                styles.hudWeaponText,
                currentWeapon > 0 && styles.hudWeaponUpgraded,
              ]}
            >
              {currentWeapon > 0 ? '⭐ ' : ''}
              {WEAPONS[currentWeapon].name} · Nv.{currentWeapon + 1}
            </Text>
          </View>
          <View style={styles.hudCoinRow}>
            <View style={styles.hudCoinDot} />
            <Text style={styles.hudCoinsText}>{coins}</Text>
          </View>
          {currentWeapon > 0 && (
            <Text style={styles.hudUpgradeText}>ARMA MEJORADA</Text>
          )}
        </View>
      </View>

      <View style={styles.ground}>
        <View style={styles.stoneRow}>
          {Array.from({ length: 8 }).map((_, index) => (
            <View key={index} style={styles.stoneBlock} />
          ))}
        </View>
        <View style={styles.grass}>
          <View style={styles.grassHighlight} />
          <View style={styles.grassTufts}>
            {Array.from({ length: 16 }).map((_, index) => (
              <View key={index} style={styles.grassTufts} />
            ))}
          </View>
        </View>
      </View>

      <TouchControls
        key={gameOver ? 'game-over' : 'playing'}
        disabled={gameOver}
        onLeftPressIn={handleLeftPressIn}
        onLeftPressOut={handleLeftPressOut}
        onRightPressIn={handleRightPressIn}
        onRightPressOut={handleRightPressOut}
        onJumpPressIn={handleJumpPressIn}
        onShootPressIn={handleShootPressIn}
      />

      <GameOverModal
        visible={gameOver}
        score={score}
        bestScore={bestScore}
        onRestart={restart}
        onExit={onExit}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    position: 'relative',
    overflow: 'hidden',
  },
  landscape: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'column',
    overflow: 'hidden',
  },
  skyBand: {
    flex: 1,
  },
  sunHalo: {
    position: 'absolute',
    top: 54,
    left: 6,
    width: 190,
    height: 190,
    borderRadius: 95,
    backgroundColor: 'rgba(255, 246, 190, 0.28)',
  },
  sun: {
    position: 'absolute',
    top: 96,
    left: 46,
    width: 104,
    height: 104,
    borderRadius: 52,
    backgroundColor: 'rgba(255, 250, 214, 0.9)',
    shadowColor: '#fff2a0',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9,
    shadowRadius: 24,
    elevation: 3,
  },
  hill: {
    position: 'absolute',
    borderTopLeftRadius: 999,
    borderTopRightRadius: 999,
  },
  hillFarOne: {
    left: '-30%',
    bottom: GROUND_HEIGHT - 6,
    width: '85%',
    height: 180,
    backgroundColor: '#b3e094',
  },
  hillFarTwo: {
    left: '30%',
    bottom: GROUND_HEIGHT - 4,
    width: '95%',
    height: 205,
    backgroundColor: '#a3d787',
  },
  hillMidOne: {
    left: '-20%',
    bottom: GROUND_HEIGHT - 10,
    width: '70%',
    height: 145,
    backgroundColor: '#83ca67',
  },
  hillMidTwo: {
    left: '42%',
    bottom: GROUND_HEIGHT - 8,
    width: '80%',
    height: 165,
    backgroundColor: '#72be56',
  },
  horizonHaze: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: GROUND_HEIGHT,
    height: 34,
    backgroundColor: 'rgba(255, 255, 255, 0.16)',
  },
  forestRow: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: GROUND_HEIGHT - 2,
    height: 54,
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-around',
    paddingHorizontal: 2,
  },
  tree: {
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  treeFoliage: {
    width: 0,
    height: 0,
    borderLeftWidth: 9,
    borderRightWidth: 9,
    borderBottomWidth: 26,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    borderBottomColor: '#2f7d3a',
  },
  treeTrunk: {
    width: 4,
    height: 8,
    backgroundColor: '#5b3d27',
    borderBottomLeftRadius: 1,
    borderBottomRightRadius: 1,
  },
  cloud: {
    position: 'absolute',
    zIndex: 1,
  },
  cloudPuff: {
    position: 'absolute',
    backgroundColor: 'rgba(255, 255, 255, 0.92)',
    borderRadius: 999,
  },
  loadingText: {
    color: COLORS.text,
    fontSize: 18,
    fontWeight: '700',
    textAlign: 'center',
    marginTop: 24,
  },
  cow: {
    position: 'absolute',
    width: COW_WIDTH,
    height: COW_HEIGHT,
  },
  obstacle: {
    position: 'absolute',
  },
  stonePlatform: {
    borderRadius: 12,
    borderWidth: 3,
    borderColor: '#4b4238',
    backgroundColor: '#6f6559',
    shadowColor: '#0a1a12',
    shadowOffset: { width: 0, height: 7 },
    shadowOpacity: 0.45,
    shadowRadius: 9,
    elevation: 8,
  },
  stoneShade: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: '38%',
    backgroundColor: 'rgba(38, 32, 26, 0.28)',
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
  },
  stoneHighlight: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 6,
    backgroundColor: 'rgba(255, 255, 255, 0.16)',
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  stoneSeamHorizontal: {
    position: 'absolute',
    left: 8,
    right: 8,
    top: '46%',
    height: 3,
    borderRadius: 2,
    backgroundColor: 'rgba(40, 35, 29, 0.4)',
  },
  stoneSeamVertical: {
    position: 'absolute',
    top: '46%',
    bottom: 8,
    left: '50%',
    width: 3,
    borderRadius: 2,
    backgroundColor: 'rgba(40, 35, 29, 0.35)',
  },
  stoneMossLeft: {
    position: 'absolute',
    left: 0,
    bottom: 0,
    width: '38%',
    height: '40%',
    backgroundColor: 'rgba(110, 180, 70, 0.32)',
    borderTopRightRadius: 26,
  },
  stoneMossRight: {
    position: 'absolute',
    right: 0,
    top: '30%',
    width: '26%',
    height: '34%',
    backgroundColor: 'rgba(110, 180, 70, 0.22)',
    borderBottomLeftRadius: 18,
  },
  woodPlatform: {
    borderRadius: 10,
    borderWidth: 3,
    borderColor: '#5a381c',
    backgroundColor: '#8a5a2f',
    shadowColor: '#1e1206',
    shadowOffset: { width: 0, height: 7 },
    shadowOpacity: 0.45,
    shadowRadius: 9,
    elevation: 8,
  },
  woodPlankLineOne: {
    position: 'absolute',
    left: 6,
    right: 6,
    top: '34%',
    height: 3,
    borderRadius: 2,
    backgroundColor: 'rgba(70, 42, 20, 0.55)',
  },
  woodPlankLineTwo: {
    position: 'absolute',
    left: 6,
    right: 6,
    top: '68%',
    height: 3,
    borderRadius: 2,
    backgroundColor: 'rgba(70, 42, 20, 0.5)',
  },
  woodGrainOne: {
    position: 'absolute',
    left: '16%',
    width: '52%',
    top: '22%',
    height: 2,
    borderRadius: 1,
    backgroundColor: 'rgba(60, 35, 15, 0.32)',
    transform: [{ rotate: '-2deg' }],
  },
  woodGrainTwo: {
    position: 'absolute',
    right: '14%',
    width: '40%',
    top: '80%',
    height: 2,
    borderRadius: 1,
    backgroundColor: 'rgba(60, 35, 15, 0.28)',
    transform: [{ rotate: '2deg' }],
  },
  woodTopHighlight: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 5,
    backgroundColor: 'rgba(255, 210, 150, 0.28)',
    borderTopLeftRadius: 8,
    borderTopRightRadius: 8,
  },
  woodMoss: {
    position: 'absolute',
    left: 0,
    bottom: 0,
    width: '34%',
    height: '30%',
    backgroundColor: 'rgba(110, 180, 70, 0.26)',
    borderTopRightRadius: 20,
  },
  platformGrass: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 14,
    backgroundColor: '#7ed957',
    borderBottomWidth: 3,
    borderBottomColor: '#4f9e2f',
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  platformGrassThin: {
    height: 8,
    borderBottomWidth: 2,
  },
  platformGrassHighlight: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.32)',
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  spikeSlot: {
    position: 'absolute',
    bottom: 0,
  },
  spike: {
    borderRadius: 10,
    shadowColor: '#ff2d2d',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9,
    shadowRadius: 12,
    elevation: 8,
  },
  spikeDirt: {
    position: 'absolute',
    left: -4,
    right: -4,
    bottom: 0,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#3f2a1b',
  },
  spikeGlow: {
    position: 'absolute',
    top: -10,
    left: -8,
    right: -8,
    bottom: -2,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: 'rgba(255, 120, 100, 0.35)',
  },
  spikeTriangle: {
    width: 0,
    height: 0,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    borderBottomColor: '#ff2b2b',
    borderTopWidth: 0,
  },
  spikeHighlight: {
    position: 'absolute',
    bottom: 0,
    width: 0,
    height: 0,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    borderBottomColor: '#ff8a6b',
    borderTopWidth: 0,
  },
  spikeBase: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: 5,
    borderRadius: 3,
    backgroundColor: '#7a1f16',
  },
  ground: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: GROUND_HEIGHT,
    backgroundColor: '#7b6650',
    borderTopWidth: 4,
    borderTopColor: '#4f3f2f',
  },
  stoneRow: {
    position: 'absolute',
    top: 26,
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'row',
    alignItems: 'stretch',
    paddingHorizontal: 4,
  },
  stoneBlock: {
    flex: 1,
    marginHorizontal: 3,
    marginVertical: 4,
    backgroundColor: '#8d765c',
    borderRadius: 6,
    borderWidth: 2,
    borderColor: '#5f4c39',
    borderTopColor: '#a8927a',
  },
  grass: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 26,
    backgroundColor: '#74c947',
    borderBottomWidth: 4,
    borderBottomColor: '#4a8c2a',
  },
  grassHighlight: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 7,
    backgroundColor: 'rgba(255, 255, 255, 0.18)',
  },
  bullet: {
    position: 'absolute',
    width: BULLET_RADIUS * 2,
    height: BULLET_RADIUS * 2,
    borderRadius: BULLET_RADIUS,
    backgroundColor: '#ffe14d',
    shadowColor: '#ff8c1a',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9,
    shadowRadius: 4,
    elevation: 6,
  },
  coin: {
    position: 'absolute',
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#ffe14d',
    borderWidth: 2,
    borderColor: '#ffb020',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#ffd54a',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 8,
    elevation: 8,
  },
  coinHalo: {
    position: 'absolute',
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: 'rgba(255, 225, 77, 0.35)',
    zIndex: 9,
  },
  coinShine: {
    position: 'absolute',
    top: 3,
    left: 4,
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
  },
  terrainSegment: {
    position: 'absolute',
    backgroundColor: COLORS.ground,
    borderTopWidth: 4,
    borderTopColor: '#a7661c',
  },
  terrainHole: {
    position: 'absolute',
    backgroundColor: '#3a2414',
    opacity: 0.7,
  },
  hud: {
    position: 'absolute',
    top: 14,
    right: 10,
    backgroundColor: 'rgba(12, 40, 58, 0.45)',
    borderRadius: 20,
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.35)',
    paddingVertical: 10,
    paddingHorizontal: 12,
    minWidth: 118,
    shadowColor: '#062033',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.35,
    shadowRadius: 14,
    elevation: 10,
  },
  hudWeapon: {
    flexDirection: 'column',
    alignItems: 'flex-end',
  },
  hudWeaponText: {
    color: COLORS.text,
    fontSize: 12,
    fontWeight: '800',
    textAlign: 'right',
  },
  hudCoinRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 6,
  },
  hudCoinDot: {
    width: 14,
    height: 14,
    borderRadius: 7,
    marginRight: 6,
    backgroundColor: '#ffe14d',
    borderWidth: 2,
    borderColor: '#ffb020',
    shadowColor: '#ffd54a',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9,
    shadowRadius: 4,
    elevation: 4,
  },
  hudCoinsText: {
    color: '#ffe14d',
    fontSize: 14,
    fontWeight: '800',
  },
  destructibleCrack: {
    position: 'absolute',
    left: '24%',
    top: '28%',
    width: 4,
    height: '42%',
    backgroundColor: 'rgba(38, 32, 26, 0.55)',
    transform: [{ rotate: '12deg' }],
  },
  destructibleCrackSmall: {
    position: 'absolute',
    left: '52%',
    top: '52%',
    width: 3,
    height: '24%',
    backgroundColor: 'rgba(38, 32, 26, 0.45)',
    transform: [{ rotate: '-18deg' }],
  },
  bossHealthBarBackground: {
    position: 'absolute',
    height: 6,
    backgroundColor: '#333333',
    borderRadius: 3,
    zIndex: 20,
  },
  bossHealthBarFill: {
    position: 'absolute',
    height: 6,
    borderRadius: 3,
    zIndex: 21,
  },
  floatingGlow: {
    position: 'absolute',
    top: -4,
    left: -4,
    right: -4,
    bottom: -4,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'rgba(255, 245, 210, 0.45)',
    backgroundColor: 'rgba(255, 245, 210, 0.08)',
  },
  hudWeaponRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 2,
  },
  hudWeaponUpgraded: {
    color: '#ffe14d',
    fontWeight: '700',
  },
  hudUpgradeText: {
    color: '#ffe14d',
    fontSize: 10,
    fontWeight: '700',
    marginTop: 2,
    textTransform: 'uppercase',
  },
  deathEffect: {
    position: 'absolute',
    alignItems: 'center',
    zIndex: 15,
  },
  deathParticle: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#ff4444',
    marginHorizontal: 2,
    shadowColor: '#ff0000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
    elevation: 6,
  },

  grassTufts: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 6,
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
 
});